var grunt = require('grunt');

module.exports = {
  plugin: [
    'src/plugin/styles/**/*'
  ],

  demo: [
    'src/demo/styles/**/*'
  ]
};