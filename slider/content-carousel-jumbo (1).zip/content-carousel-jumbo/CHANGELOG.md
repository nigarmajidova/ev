<a name="1.5.0"></a>
# 1.5.0 (2020-01-25)



<a name="1.4.5"></a>
## 1.4.5 (2017-06-02)


### Bug Fixes

* **Silent focus:** Focus slider on mouse enter ([282167b](https://github.com/martinmethod/jumboslider/commit/282167b))



<a name="1.4.0"></a>
# 1.4.0 (2017-05-31)


### Bug Fixes

* **Overview width:** Wrong calculations ([aacd891](https://github.com/martinmethod/jumboslider/commit/aacd891))


### Features

* **Autoplay:** Ability to slide automatically ([b44bc46](https://github.com/martinmethod/jumboslider/commit/b44bc46))
* **Transition:** Ability to define the transition speed ([0d121f0](https://github.com/martinmethod/jumboslider/commit/0d121f0))



<a name="1.3.2"></a>
## 1.3.2 (2017-04-11)


### Bug Fixes

* **githubUsername:** Broken object ([50d06fa](https://github.com/martinmethod/jumboslider/commit/50d06fa))


### Features

* **Banner:** External text configuration ([65588d4](https://github.com/martinmethod/jumboslider/commit/65588d4))



<a name="1.3.1"></a>
## 1.3.1 (2017-04-11)


### Features

* **Arrows:** Arrows are now white ([f814a5b](https://github.com/martinmethod/jumboslider/commit/f814a5b))
* **Build:** External markup support ([ed2b370](https://github.com/martinmethod/jumboslider/commit/ed2b370))



<a name="1.3.0"></a>
# 1.3.0 (2017-04-05)


### Features

* **Deploy:** npm, GitHub Pages & GitHub Releases ([3910056](https://github.com/martinmethod/jumboslider/commit/3910056))



<a name="1.2.0"></a>
# 1.2.0 (2017-04-03)


### Features

* **Building system:** Refactored building system ([3f9ca30](https://github.com/martinmethod/jumboslider/commit/3f9ca30))



